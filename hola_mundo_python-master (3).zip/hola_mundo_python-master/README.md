![Inove banner](/inove.jpg)
Inove Escuela de Código\
info@inove.com.ar\
Web: [Inove](http://inove.com.ar)

# Hola Mundo! [Python]
Programa creado para ensayar el correcto funcionamiento del entorno de instalación Python

# Consultas
alumnos@inove.com.ar

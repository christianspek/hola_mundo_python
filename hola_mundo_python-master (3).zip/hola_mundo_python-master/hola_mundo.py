# Hola Mundo! [Python]
# ---------------------------
# Autor: Inove Coding School
# Version: 2.0

# Descripcion:
# Programa creado para ensayar el correcto funcionamiento
# del entorno de instalación Python


print("Hola Mundo!")
